# Emial validation 
import re
# pattern = re.compile(r'^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,7}$')
pattern = re.compile(r'^[0-9]{10}$')
email = input("Enter your email : ")

if pattern.search(email):
    print("Valid Email")
else:
    print("Invalide email ! Try again")