# use search method 
import re
s="Hello python"
a=re.search("Hello",s)
print(a)